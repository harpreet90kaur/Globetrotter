﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace GlobeTrotter
{
    [Activity(Label = "Bookings_Activity")]
    public class Bookings_Activity : Activity
    {
        ListView list_element;
        List<BookingObj> bookingList = new List<BookingObj>();
        DatabaseHelper dbhelper;
        string useremail;
        BookingObj bobj;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.bookings_layout);
            useremail = Intent.GetStringExtra("useremail");
            // Create your application here

            list_element = FindViewById<ListView>(Resource.Id.bookingList);

            bobj = new BookingObj();
            dbhelper = new DatabaseHelper(this);
            bookingList = dbhelper.GetUserBookings(useremail);
            if (bookingList.Count > 0)
            {
                var bookingAdapter = new Bookings_Adapter(this, bookingList);
                list_element.SetAdapter(bookingAdapter);
            }

        }
    }
}